#ifndef KEYPAIR_H
#define KEYPAIR_H

extern void generate_keypair(void);
extern void verify_keypair(void);

#endif /* KEYPAIR_H */
